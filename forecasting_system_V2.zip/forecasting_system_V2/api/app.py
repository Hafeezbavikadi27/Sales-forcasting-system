"""
REST API for the Forecasting System.
Exposes endpoints to query forecasts, model metadata, and per-state predictions.

Run:
    uvicorn api.app:app --host 0.0.0.0 --port 8000 --reload
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import json
import pandas as pd
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Optional

from config import OUTPUT_DIR, MODEL_DIR, FORECAST_HORIZON

app = FastAPI(
    title="Sales Forecasting API",
    description=(
        "Production-ready REST API for weekly beverage-sales forecasting across US states. "
        "Trains SARIMA, Prophet, XGBoost, and LSTM models; automatically selects the best."
    ),
    version="1.0.0",
)


# ── Helper: load cached artefacts ──────────────────────────────────────
def _load_meta():
    path = os.path.join(OUTPUT_DIR, "pipeline_meta.json")
    if not os.path.exists(path):
        raise HTTPException(503, "Pipeline has not been run yet. Execute train_pipeline.py first.")
    with open(path) as f:
        return json.load(f)


def _load_forecasts():
    path = os.path.join(OUTPUT_DIR, "forecasts.csv")
    if not os.path.exists(path):
        raise HTTPException(503, "No forecasts found. Run the training pipeline first.")
    return pd.read_csv(path)


def _load_validation():
    path = os.path.join(OUTPUT_DIR, "validation_results.csv")
    if not os.path.exists(path):
        raise HTTPException(503, "No validation results found.")
    return pd.read_csv(path)


# ── Response schemas ───────────────────────────────────────────────────
class ForecastRow(BaseModel):
    Date: str
    State: str
    Predicted: float


class HealthResponse(BaseModel):
    status: str
    best_model: str
    states_available: int
    forecast_horizon_weeks: int


class ModelSummary(BaseModel):
    model: str
    Mean_MAPE: float
    Median_MAPE: float
    Std_MAPE: float
    training_time_sec: float


# ── Endpoints ──────────────────────────────────────────────────────────
@app.get("/", tags=["Root"])
def root():
    return {"message": "Sales Forecasting API is running. Visit /docs for interactive docs."}


@app.get("/health", response_model=HealthResponse, tags=["System"])
def health():
    """Health-check / readiness endpoint."""
    meta = _load_meta()
    return HealthResponse(
        status="healthy",
        best_model=meta["best_model"],
        states_available=len(meta["states"]),
        forecast_horizon_weeks=meta["forecast_horizon_weeks"],
    )


@app.get("/models/summary", response_model=List[ModelSummary], tags=["Models"])
def model_summary():
    """Return evaluation summary for all trained models."""
    meta = _load_meta()
    out = []
    for name, scores in meta["summary"].items():
        out.append(ModelSummary(
            model=name,
            Mean_MAPE=scores["Mean_MAPE"],
            Median_MAPE=scores["Median_MAPE"],
            Std_MAPE=scores["Std_MAPE"],
            training_time_sec=meta["training_times_sec"][name],
        ))
    return sorted(out, key=lambda x: x.Mean_MAPE)


@app.get("/models/best", tags=["Models"])
def best_model():
    """Return name and metrics of the auto-selected best model."""
    meta = _load_meta()
    name = meta["best_model"]
    return {
        "best_model": name,
        "metrics": meta["summary"][name],
        "training_time_sec": meta["training_times_sec"][name],
    }


@app.get("/states", tags=["Data"])
def list_states():
    """List all states available for forecasting."""
    meta = _load_meta()
    return {"states": meta["states"]}


@app.get("/forecast", response_model=List[ForecastRow], tags=["Forecasts"])
def get_forecast(
    state: Optional[str] = Query(None, description="Filter by state name (e.g. 'California')"),
    limit: int = Query(100, ge=1, le=1000, description="Max rows to return"),
):
    """
    Return 8-week-ahead forecasts produced by the best model.
    Optionally filter by state.
    """
    df = _load_forecasts()
    if state:
        df = df[df["State"].str.lower() == state.lower()]
        if df.empty:
            raise HTTPException(404, f"State '{state}' not found.")
    df = df.head(limit)
    return df.to_dict(orient="records")


@app.get("/forecast/{state}", response_model=List[ForecastRow], tags=["Forecasts"])
def get_forecast_by_state(state: str):
    """Return 8-week forecast for a specific state (path param)."""
    df = _load_forecasts()
    match = df[df["State"].str.lower() == state.lower()]
    if match.empty:
        raise HTTPException(404, f"State '{state}' not found. Use /states for the full list.")
    return match.to_dict(orient="records")


@app.get("/validation", tags=["Evaluation"])
def validation_results(
    state: Optional[str] = Query(None),
    model: Optional[str] = Query(None),
):
    """Return per-state validation metrics. Filter by state and/or model."""
    df = _load_validation()
    if state:
        df = df[df["State"].str.lower() == state.lower()]
    if model:
        df = df[df["Model"].str.lower() == model.lower()]
    if df.empty:
        raise HTTPException(404, "No matching validation records.")
    return df.to_dict(orient="records")


@app.get("/validation/leaderboard", tags=["Evaluation"])
def leaderboard():
    """Rank models by mean MAPE across all states."""
    meta = _load_meta()
    ranked = sorted(meta["summary"].items(), key=lambda x: x[1]["Mean_MAPE"])
    return [{"rank": i + 1, "model": name, **scores} for i, (name, scores) in enumerate(ranked)]
