"""
train_pipeline.py -- End-to-end training, evaluation, and model selection.
Usage: python train_pipeline.py
"""
import sys, os, json, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings("ignore")

from config import (
    RAW_DATA_PATH, LAG_FEATURES, ROLLING_WINDOWS,
    VALIDATION_WEEKS, FORECAST_HORIZON, MODEL_DIR, OUTPUT_DIR,
)
from data.preprocessing import load_and_clean, build_features, train_val_split
from utils.metrics import evaluate
from models.sarima_model import SARIMAForecaster
from models.prophet_model import ProphetForecaster
from models.xgboost_model import XGBoostForecaster
from models.lstm_model import LSTMForecaster


def run_pipeline():
    print("=" * 70)
    print("  TIME-SERIES FORECASTING PIPELINE")
    print("=" * 70)

    # 1. Load & preprocess
    print("\n[1/6] Loading and cleaning data...")
    df_raw = load_and_clean(RAW_DATA_PATH)
    states = sorted(df_raw["State"].unique())
    print(f"  -> {len(states)} states, {df_raw.shape[0]} rows, "
          f"range {df_raw['Date'].min().date()} -> {df_raw['Date'].max().date()}")

    # 2. Feature engineering
    print("\n[2/6] Engineering features...")
    df_feat = build_features(df_raw, LAG_FEATURES, ROLLING_WINDOWS)
    print(f"  -> {df_feat.shape[1]} columns")

    # 3. Train/val split
    print(f"\n[3/6] Time-series split (last {VALIDATION_WEEKS} weeks = validation)...")
    train_df, val_df = train_val_split(df_feat, VALIDATION_WEEKS)
    train_raw, val_raw = train_val_split(df_raw, VALIDATION_WEEKS)
    print(f"  -> Train: {train_df.shape[0]} | Val: {val_df.shape[0]}")

    per_state_results = []

    # 4a. SARIMA
    print("\n[4a/6] Training SARIMA...")
    t0 = time.time()
    sarima = SARIMAForecaster(seasonal_period=13)
    sarima.fit(train_raw)
    sarima_time = time.time() - t0
    for s in states:
        pred = sarima.predict(s, VALIDATION_WEEKS)
        actual = val_raw[val_raw["State"] == s].sort_values("Date")["Total"].values
        n = min(len(actual), len(pred))
        if n > 0:
            m = evaluate(actual[:n], pred["Predicted"].values[:n])
            per_state_results.append({"State": s, "Model": "SARIMA", **m})

    # 4b. Prophet
    print("\n[4b/6] Training Prophet...")
    t0 = time.time()
    prophet = ProphetForecaster()
    prophet.fit(train_raw)
    prophet_time = time.time() - t0
    for s in states:
        pred = prophet.predict(s, VALIDATION_WEEKS)
        actual = val_raw[val_raw["State"] == s].sort_values("Date")["Total"].values
        n = min(len(actual), len(pred))
        if n > 0:
            m = evaluate(actual[:n], pred["Predicted"].values[:n])
            per_state_results.append({"State": s, "Model": "Prophet", **m})

    # 4c. XGBoost
    print("\n[4c/6] Training XGBoost...")
    t0 = time.time()
    xgb_model = XGBoostForecaster()
    xgb_model.fit(train_df)
    xgb_time = time.time() - t0
    xgb_val = xgb_model.predict_validation(val_df)
    for s in states:
        sv = xgb_val[xgb_val["State"] == s].sort_values("Date")
        if len(sv) > 0:
            m = evaluate(sv["Total"].values, sv["Predicted"].values)
            per_state_results.append({"State": s, "Model": "XGBoost", **m})
    print("  XGBoost validated all states")

    # 4d. LSTM
    print("\n[4d/6] Training LSTM...")
    t0 = time.time()
    lstm = LSTMForecaster(lookback=12)
    lstm.fit(train_raw)
    lstm_time = time.time() - t0
    for s in states:
        pred = lstm.predict(train_raw, s, VALIDATION_WEEKS)
        actual = val_raw[val_raw["State"] == s].sort_values("Date")["Total"].values
        n = min(len(actual), len(pred))
        if n > 0:
            m = evaluate(actual[:n], pred["Predicted"].values[:n])
            per_state_results.append({"State": s, "Model": "LSTM", **m})

    # 5. Compare models
    print("\n[5/6] Comparing models...")
    results_df = pd.DataFrame(per_state_results)
    summary = {}
    training_times = {"SARIMA": round(sarima_time, 1), "Prophet": round(prophet_time, 1),
                      "XGBoost": round(xgb_time, 1), "LSTM": round(lstm_time, 1)}
    for name in ["SARIMA", "Prophet", "XGBoost", "LSTM"]:
        mapes = results_df[results_df["Model"] == name]["MAPE"].values
        summary[name] = {
            "Mean_MAPE": round(float(np.mean(mapes)), 2),
            "Median_MAPE": round(float(np.median(mapes)), 2),
            "Std_MAPE": round(float(np.std(mapes)), 2),
        }

    print(f"\n{'='*60}")
    print(f"  {'Model':<12} {'Mean MAPE%':>12} {'Median MAPE%':>14} {'Std':>8} {'Time(s)':>10}")
    print(f"{'='*60}")
    for name in ["SARIMA", "Prophet", "XGBoost", "LSTM"]:
        s = summary[name]
        print(f"  {name:<12} {s['Mean_MAPE']:>12.2f} {s['Median_MAPE']:>14.2f} "
              f"{s['Std_MAPE']:>8.2f} {training_times[name]:>10.1f}")
    print(f"{'='*60}")

    best_model_name = min(summary, key=lambda k: summary[k]["Mean_MAPE"])
    print(f"\n  ** Best model: {best_model_name} (Mean MAPE = {summary[best_model_name]['Mean_MAPE']:.2f}%)")

    # 6. Generate forecasts
    print(f"\n[6/6] Generating {FORECAST_HORIZON}-week forecasts with {best_model_name}...")

    if best_model_name == "SARIMA":
        forecasts = sarima.predict_all(states, FORECAST_HORIZON)
    elif best_model_name == "Prophet":
        forecasts = prophet.predict_all(states, FORECAST_HORIZON)
    elif best_model_name == "XGBoost":
        forecasts = xgb_model.predict_all(df_feat, states, FORECAST_HORIZON)
    else:
        forecasts = lstm.predict_all(df_raw, states, FORECAST_HORIZON)

    # Save
    sarima.save(os.path.join(MODEL_DIR, "sarima.pkl"))
    prophet.save(os.path.join(MODEL_DIR, "prophet.pkl"))
    xgb_model.save(os.path.join(MODEL_DIR, "xgboost.pkl"))
    lstm.save(os.path.join(MODEL_DIR, "lstm"))

    forecasts.to_csv(os.path.join(OUTPUT_DIR, "forecasts.csv"), index=False)
    results_df.to_csv(os.path.join(OUTPUT_DIR, "validation_results.csv"), index=False)

    meta = {
        "best_model": best_model_name,
        "summary": summary,
        "training_times_sec": training_times,
        "states": states,
        "forecast_horizon_weeks": FORECAST_HORIZON,
        "validation_weeks": VALIDATION_WEEKS,
    }
    with open(os.path.join(OUTPUT_DIR, "pipeline_meta.json"), "w") as f:
        json.dump(meta, f, indent=2)

    print(f"\n  Outputs -> {OUTPUT_DIR}/")
    print("DONE: Pipeline complete!")
    return meta, forecasts, results_df


if __name__ == "__main__":
    run_pipeline()
