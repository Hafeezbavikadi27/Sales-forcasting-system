"""
Facebook Prophet model for weekly sales forecasting.
Handles per-state fitting with US holiday support.
"""
import pandas as pd
import numpy as np
from prophet import Prophet
import warnings, pickle
warnings.filterwarnings("ignore")
import logging
logging.getLogger("prophet").setLevel(logging.ERROR)
logging.getLogger("cmdstanpy").setLevel(logging.ERROR)


class ProphetForecaster:

    def __init__(self):
        self.models = {}

    def _fit_single(self, series_df: pd.DataFrame) -> Prophet:
        m = Prophet(
            yearly_seasonality=True,
            weekly_seasonality=False,
            daily_seasonality=False,
            changepoint_prior_scale=0.05,
            seasonality_prior_scale=10,
        )
        m.add_country_holidays(country_name="US")
        m.fit(series_df)
        return m

    def fit(self, df: pd.DataFrame):
        for state in df["State"].unique():
            grp = df[df["State"] == state][["Date", "Total"]].copy()
            grp.columns = ["ds", "y"]
            grp = grp.sort_values("ds").reset_index(drop=True)
            self.models[state] = self._fit_single(grp)
            print(f"  Prophet fitted: {state}")

    def predict(self, state: str, steps: int = 8) -> pd.DataFrame:
        m = self.models[state]
        future = m.make_future_dataframe(periods=steps, freq="W-SUN")
        fc = m.predict(future)
        fc = fc.tail(steps)[["ds", "yhat"]].rename(columns={"ds": "Date", "yhat": "Predicted"})
        return fc.reset_index(drop=True)

    def predict_all(self, states: list, steps: int = 8) -> pd.DataFrame:
        frames = []
        for s in states:
            pred = self.predict(s, steps)
            pred["State"] = s
            frames.append(pred)
        return pd.concat(frames, ignore_index=True)

    def save(self, path: str):
        with open(path, "wb") as f:
            pickle.dump(self.models, f)

    def load(self, path: str):
        with open(path, "rb") as f:
            self.models = pickle.load(f)
