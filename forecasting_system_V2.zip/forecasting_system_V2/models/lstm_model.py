"""
LSTM-based deep learning forecaster for weekly sales.
Uses a sliding-window approach with sequence length = lookback weeks.
One model trained globally across all states.
"""
import pandas as pd
import numpy as np
import pickle, warnings, os
warnings.filterwarnings("ignore")
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

import tensorflow as tf
tf.get_logger().setLevel("ERROR")
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping
from sklearn.preprocessing import MinMaxScaler, LabelEncoder


class LSTMForecaster:

    def __init__(self, lookback: int = 12):
        self.lookback = lookback
        self.model = None
        self.scalers = {}  # per-state scalers
        self.le = LabelEncoder()

    def _build_model(self, n_features: int):
        model = Sequential([
            LSTM(64, return_sequences=True, input_shape=(self.lookback, n_features)),
            Dropout(0.2),
            LSTM(32),
            Dropout(0.2),
            Dense(16, activation="relu"),
            Dense(1),
        ])
        model.compile(optimizer="adam", loss="mse")
        return model

    def _make_sequences(self, data: np.ndarray):
        X, y = [], []
        for i in range(self.lookback, len(data)):
            X.append(data[i - self.lookback : i])
            y.append(data[i, 0])  # target = first column (scaled Total)
        return np.array(X), np.array(y)

    def fit(self, df: pd.DataFrame):
        df = df.sort_values(["State", "Date"]).copy()
        states = df["State"].unique()
        self.le.fit(states)

        all_X, all_y = [], []
        for state in states:
            grp = df[df["State"] == state].sort_values("Date")
            vals = grp["Total"].values.reshape(-1, 1)

            scaler = MinMaxScaler()
            scaled = scaler.fit_transform(vals)
            self.scalers[state] = scaler

            # Add simple temporal features: month sin/cos
            months = grp["Date"].dt.month.values
            month_sin = np.sin(2 * np.pi * months / 12).reshape(-1, 1)
            month_cos = np.cos(2 * np.pi * months / 12).reshape(-1, 1)
            features = np.hstack([scaled, month_sin, month_cos])

            X, y = self._make_sequences(features)
            if len(X) > 0:
                all_X.append(X)
                all_y.append(y)

        X_all = np.concatenate(all_X)
        y_all = np.concatenate(all_y)

        self.model = self._build_model(X_all.shape[2])
        self.model.fit(
            X_all, y_all,
            epochs=30, batch_size=64, verbose=0,
            validation_split=0.1,
            callbacks=[EarlyStopping(patience=3, restore_best_weights=True)],
        )
        print("  LSTM fitted (global model)")

    def predict(self, df: pd.DataFrame, state: str, steps: int = 8) -> pd.DataFrame:
        grp = df[df["State"] == state].sort_values("Date")
        vals = grp["Total"].values.reshape(-1, 1)
        scaler = self.scalers[state]
        scaled = scaler.transform(vals)

        months = grp["Date"].dt.month.values
        month_sin = np.sin(2 * np.pi * months / 12).reshape(-1, 1)
        month_cos = np.cos(2 * np.pi * months / 12).reshape(-1, 1)
        seq = np.hstack([scaled, month_sin, month_cos])

        window = seq[-self.lookback:].copy()
        preds, dates = [], []
        last_date = grp["Date"].max()

        for step in range(steps):
            new_date = last_date + pd.Timedelta(weeks=step + 1)
            inp = window.reshape(1, self.lookback, -1)
            pred_scaled = self.model.predict(inp, verbose=0)[0, 0]

            pred_val = scaler.inverse_transform([[pred_scaled]])[0, 0]
            pred_val = max(pred_val, 0)
            preds.append(pred_val)
            dates.append(new_date)

            # Slide window
            m = new_date.month
            new_feat = np.array([[pred_scaled, np.sin(2*np.pi*m/12), np.cos(2*np.pi*m/12)]])
            window = np.vstack([window[1:], new_feat])

        return pd.DataFrame({"Date": dates, "Predicted": preds})

    def predict_all(self, df: pd.DataFrame, states: list, steps: int = 8) -> pd.DataFrame:
        frames = []
        for s in states:
            pred = self.predict(df, s, steps)
            pred["State"] = s
            frames.append(pred)
        return pd.concat(frames, ignore_index=True)

    def save(self, path: str):
        self.model.save(path + ".keras")
        with open(path + "_meta.pkl", "wb") as f:
            pickle.dump({"scalers": self.scalers, "le": self.le, "lookback": self.lookback}, f)

    def load(self, path: str):
        self.model = tf.keras.models.load_model(path + ".keras")
        with open(path + "_meta.pkl", "rb") as f:
            meta = pickle.load(f)
        self.scalers, self.le, self.lookback = meta["scalers"], meta["le"], meta["lookback"]
