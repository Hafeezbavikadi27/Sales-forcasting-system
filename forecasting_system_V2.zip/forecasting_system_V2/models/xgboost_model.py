"""
XGBoost forecaster with engineered lag/rolling/calendar features.
Trains one global model across all states (with state encoding) and
supports recursive multi-step forecasting.
"""
import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.preprocessing import LabelEncoder
import pickle, warnings
warnings.filterwarnings("ignore")

from data.preprocessing import (
    build_features, get_feature_columns, add_calendar_features,
    add_lag_features, add_rolling_features,
)
from config import LAG_FEATURES, ROLLING_WINDOWS


class XGBoostForecaster:

    def __init__(self):
        self.model = None
        self.le = LabelEncoder()
        self.feature_cols = []

    def _prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        df["state_enc"] = self.le.fit_transform(df["State"])
        return df

    def fit(self, train_df: pd.DataFrame):
        df = self._prepare(train_df)
        self.feature_cols = get_feature_columns(df)
        if "state_enc" not in self.feature_cols:
            self.feature_cols.append("state_enc")

        df = df.dropna(subset=self.feature_cols)
        X = df[self.feature_cols].values
        y = df["Total"].values

        self.model = xgb.XGBRegressor(
            n_estimators=500, max_depth=6, learning_rate=0.05,
            subsample=0.8, colsample_bytree=0.8,
            reg_alpha=0.1, reg_lambda=1.0,
            n_jobs=-1, random_state=42,
        )
        self.model.fit(X, y, verbose=False)
        print("  XGBoost fitted (global model)")

    def predict(self, full_df: pd.DataFrame, state: str, steps: int = 8) -> pd.DataFrame:
        """Recursive multi-step forecast: predict one week, append, repeat."""
        state_df = full_df[full_df["State"] == state].copy().sort_values("Date")
        state_enc = self.le.transform([state])[0]
        preds, dates = [], []

        for step in range(steps):
            last_date = state_df["Date"].max()
            new_date = last_date + pd.Timedelta(weeks=1)

            # Build a one-row DataFrame for the new date
            new_row = pd.DataFrame({"Date": [new_date], "State": [state], "Total": [np.nan], "Category": ["Beverages"]})
            temp = pd.concat([state_df, new_row], ignore_index=True)

            # Re-engineer features on entire history + new row
            temp = build_features(temp, LAG_FEATURES, ROLLING_WINDOWS)
            temp["state_enc"] = state_enc

            row = temp.iloc[-1:]
            feat = row[self.feature_cols].fillna(0).values
            pred_val = float(self.model.predict(feat)[0])
            pred_val = max(pred_val, 0)

            preds.append(pred_val)
            dates.append(new_date)

            # Append actual prediction back for next lag computation
            new_row["Total"] = pred_val
            state_df = pd.concat([state_df, new_row], ignore_index=True)

        return pd.DataFrame({"Date": dates, "Predicted": preds})

    def predict_validation(self, val_df: pd.DataFrame) -> pd.DataFrame:
        """Direct prediction on validation set (features already computed)."""
        df = val_df.copy()
        df["state_enc"] = self.le.transform(df["State"])
        df = df.dropna(subset=self.feature_cols)
        X = df[self.feature_cols].fillna(0).values
        df["Predicted"] = self.model.predict(X)
        df["Predicted"] = df["Predicted"].clip(lower=0)
        return df[["Date", "State", "Predicted", "Total"]]

    def predict_all(self, full_df: pd.DataFrame, states: list, steps: int = 8) -> pd.DataFrame:
        frames = []
        for s in states:
            pred = self.predict(full_df, s, steps)
            pred["State"] = s
            frames.append(pred)
        return pd.concat(frames, ignore_index=True)

    def save(self, path: str):
        with open(path, "wb") as f:
            pickle.dump({"model": self.model, "le": self.le, "feature_cols": self.feature_cols}, f)

    def load(self, path: str):
        with open(path, "rb") as f:
            data = pickle.load(f)
        self.model, self.le, self.feature_cols = data["model"], data["le"], data["feature_cols"]
