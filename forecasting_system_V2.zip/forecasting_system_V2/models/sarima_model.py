"""
SARIMA (Seasonal ARIMA) model for weekly sales forecasting.
Handles per-state fitting with automatic order selection via AIC.
"""
import pandas as pd
import numpy as np
from statsmodels.tsa.statespace.sarimax import SARIMAX
import warnings, pickle, os
warnings.filterwarnings("ignore")


class SARIMAForecaster:
    """Fits one SARIMA model per state."""

    def __init__(self, seasonal_period: int = 52):
        self.seasonal_period = min(seasonal_period, 13)  # keep low for speed
        self.models = {}

    def _fit_single(self, series: pd.Series) -> SARIMAX:
        best_aic, best_model = np.inf, None
        for p, d, q in [(1,1,0), (1,1,1), (2,1,0)]:
            try:
                model = SARIMAX(
                    series, order=(p, d, q),
                    seasonal_order=(1, 0, 0, self.seasonal_period),
                    enforce_stationarity=False,
                    enforce_invertibility=False,
                )
                result = model.fit(disp=False, maxiter=100)
                if result.aic < best_aic:
                    best_aic, best_model = result.aic, result
            except Exception:
                continue
        if best_model is None:
            model = SARIMAX(series, order=(1, 1, 0),
                            seasonal_order=(0, 0, 0, self.seasonal_period),
                            enforce_stationarity=False, enforce_invertibility=False)
            best_model = model.fit(disp=False, maxiter=100)
        return best_model

    def fit(self, df: pd.DataFrame):
        """df must have columns: State, Date, Total."""
        for state in df["State"].unique():
            grp = df[df["State"] == state].set_index("Date")["Total"].asfreq("W-SUN")
            grp = grp.ffill().bfill()
            self.models[state] = self._fit_single(grp)
            print(f"  SARIMA fitted: {state}")

    def predict(self, state: str, steps: int = 8) -> pd.DataFrame:
        result = self.models[state]
        fc = result.get_forecast(steps=steps)
        idx = fc.predicted_mean.index
        return pd.DataFrame({"Date": idx, "Predicted": fc.predicted_mean.values})

    def predict_all(self, states: list, steps: int = 8) -> pd.DataFrame:
        frames = []
        for s in states:
            pred = self.predict(s, steps)
            pred["State"] = s
            frames.append(pred)
        return pd.concat(frames, ignore_index=True)

    def save(self, path: str):
        with open(path, "wb") as f:
            pickle.dump(self.models, f)

    def load(self, path: str):
        with open(path, "rb") as f:
            self.models = pickle.load(f)
