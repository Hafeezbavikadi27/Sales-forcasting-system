# Sales Forecasting System — End-to-End Time Series Pipeline with REST API - V2

A **production-ready** forecasting system that trains 4 algorithms (SARIMA, Prophet, XGBoost, LSTM), automatically selects the best-performing model, and serves 8-week-ahead beverage-sales predictions for 43 US states via a **FastAPI** REST API.

## Evaluation & Model Selection

### Train / Validation Split
- **Method**: Temporal split per state — last 8 weeks held out (no data leakage)
- **Train**: 10,664 rows | **Validation**: 344 rows (8 weeks × 43 states)

### Results

| Model   | Mean MAPE (%) | Median MAPE (%) | Std   | Training Time |
|---------|:-------------:|:---------------:|:-----:|:-------------:|
| **SARIMA** | **13.00**  | **13.03**       | 0.67  | 7.9s          |
| LSTM    | 15.64         | 15.66           | 1.76  | 43.8s         |
| Prophet | 31.50         | 31.62           | 2.40  | 3.7s          |
| XGBoost | 51.05         | 49.25           | 7.82  | 1.7s          |

**Winner: SARIMA** — lowest mean MAPE (13.00%) with the most consistent performance across states (lowest std).

---

## REST API Reference

Base URL: `http://localhost:8000`

| Endpoint                   | Method | Description                              |
|----------------------------|--------|------------------------------------------|
| `/`                        | GET    | Root – confirms API is running           |
| `/health`                  | GET    | Health check: best model, state count    |
| `/states`                  | GET    | List all 43 available states             |
| `/models/summary`          | GET    | All 4 models with MAPE/RMSE/MAE         |
| `/models/best`             | GET    | Auto-selected best model + metrics       |
| `/forecast?state=X`        | GET    | 8-week forecast (optional state filter)  |
| `/forecast/{state}`        | GET    | 8-week forecast for a specific state     |
| `/validation`              | GET    | Per-state validation metrics             |
| `/validation/leaderboard`  | GET    | Models ranked by Mean MAPE               |
| `/docs`                    | GET    | Interactive Swagger UI documentation     |

### Example Requests

```bash
# Health check
curl http://localhost:8000/health

# Get forecast for California
curl http://localhost:8000/forecast/California

# Model leaderboard
curl http://localhost:8000/validation/leaderboard

# Validation metrics for a specific state + model
curl "http://localhost:8000/validation?state=Texas&model=SARIMA"
```

### Example Response — `/forecast/California`
```json
[
  {"Date": "2023-10-15", "State": "California", "Predicted": 790899464.39},
  {"Date": "2023-10-22", "State": "California", "Predicted": 785432110.52},
  {"Date": "2023-10-29", "State": "California", "Predicted": 792145678.91},
  ...
]
```



## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the training pipeline (trains 4 models, evaluates, selects best)
python train_pipeline.py

# 3. Start the REST API
uvicorn api.app:app --host 0.0.0.0 --port 8000 --reload

# 4. Open interactive docs
open http://localhost:8000/docs
```

