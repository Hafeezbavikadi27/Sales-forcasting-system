"""
Configuration for the Forecasting System.
"""
import os

# Paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
MODEL_DIR = os.path.join(BASE_DIR, "models", "saved")
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Data
RAW_DATA_PATH = os.path.join(DATA_DIR, "Forecasting_Case-_Study.xlsx")

# Forecasting
FORECAST_HORIZON = 8          # 8 weeks ahead
VALIDATION_WEEKS = 8          # last 8 weeks for validation
FREQUENCY = "W"               # weekly frequency

# Feature engineering
LAG_FEATURES = [1, 2, 3, 4, 7, 13, 26]   # weeks: t-1, t-2, ..., t-26
ROLLING_WINDOWS = [4, 8, 13, 26]          # 1-month, 2-month, quarter, half-year

# Model selection
METRIC = "MAPE"  # primary metric for comparison

# API
API_HOST = "0.0.0.0"
API_PORT = 8000
