"""
Data loading, cleaning, and feature engineering pipeline.
Handles missing dates, creates lag/rolling features, calendar features, and train/val splits.
"""
import pandas as pd
import numpy as np
from typing import Tuple, Dict, List
import warnings
warnings.filterwarnings("ignore")


def load_and_clean(filepath: str) -> pd.DataFrame:
    """Load raw Excel data and normalise dates to weekly frequency."""
    df = pd.read_excel(filepath)
    df["Date"] = pd.to_datetime(df["Date"], dayfirst=True, format="mixed")
    df = df.sort_values(["State", "Date"]).reset_index(drop=True)

    # Resample to uniform weekly frequency per state, filling gaps
    frames = []
    for state, grp in df.groupby("State"):
        grp = grp.set_index("Date").resample("W-SUN").agg({"Total": "sum", "Category": "first"}).reset_index()
        grp["State"] = state
        # Forward-fill then back-fill any missing sales (sparse early dates)
        grp["Total"] = grp["Total"].replace(0, np.nan).ffill().bfill()
        grp["Category"] = grp["Category"].ffill().bfill()
        frames.append(grp)

    out = pd.concat(frames, ignore_index=True)
    out = out.sort_values(["State", "Date"]).reset_index(drop=True)
    return out


def add_calendar_features(df: pd.DataFrame) -> pd.DataFrame:
    """Add temporal / calendar features derived from the Date column."""
    df = df.copy()
    df["year"] = df["Date"].dt.year
    df["month"] = df["Date"].dt.month
    df["week_of_year"] = df["Date"].dt.isocalendar().week.astype(int)
    df["day_of_week"] = df["Date"].dt.dayofweek
    df["quarter"] = df["Date"].dt.quarter
    df["is_month_start"] = (df["Date"].dt.day <= 7).astype(int)
    df["is_month_end"] = (df["Date"].dt.day >= 24).astype(int)

    # Simple US-holiday proximity flag (major holidays: weeks containing them)
    us_holidays_mmdd = [
        (1, 1), (7, 4), (11, 25), (12, 25), (12, 31),  # New Year, July 4, Thanksgiving-ish, Xmas, NYE
        (2, 14), (5, 25), (9, 7), (10, 31),             # Valentine, MemDay-ish, LaborDay-ish, Halloween
    ]
    df["holiday_flag"] = 0
    for m, d in us_holidays_mmdd:
        mask = (df["Date"].dt.month == m) & (df["Date"].dt.day.between(d - 3, d + 3))
        df.loc[mask, "holiday_flag"] = 1
    return df


def add_lag_features(df: pd.DataFrame, lags: List[int], target: str = "Total") -> pd.DataFrame:
    """Create lag features per state (no data leakage — lags only look backward)."""
    df = df.copy()
    for lag in lags:
        df[f"lag_{lag}"] = df.groupby("State")[target].shift(lag)
    return df


def add_rolling_features(df: pd.DataFrame, windows: List[int], target: str = "Total") -> pd.DataFrame:
    """Create rolling-window statistics per state."""
    df = df.copy()
    for w in windows:
        rolled = df.groupby("State")[target].transform(lambda x: x.shift(1).rolling(w, min_periods=1).mean())
        df[f"roll_mean_{w}"] = rolled
        rolled_std = df.groupby("State")[target].transform(lambda x: x.shift(1).rolling(w, min_periods=1).std())
        df[f"roll_std_{w}"] = rolled_std
    return df


def build_features(df: pd.DataFrame, lags: List[int], windows: List[int]) -> pd.DataFrame:
    """Full feature-engineering pipeline."""
    df = add_calendar_features(df)
    df = add_lag_features(df, lags)
    df = add_rolling_features(df, windows)
    return df


def train_val_split(df: pd.DataFrame, val_weeks: int = 8) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Time-series–safe split: last `val_weeks` weeks of each state go to validation.
    No future data leaks into training.
    """
    cutoff = df.groupby("State")["Date"].transform(
        lambda x: x.max() - pd.Timedelta(weeks=val_weeks)
    )
    train = df[df["Date"] <= cutoff].copy()
    val = df[df["Date"] > cutoff].copy()
    return train, val


def get_feature_columns(df: pd.DataFrame) -> List[str]:
    """Return the list of ML feature columns (everything except target/meta)."""
    exclude = {"State", "Date", "Total", "Category"}
    return [c for c in df.columns if c not in exclude]


# ── quick test ──────────────────────────────────────────────────────────
if __name__ == "__main__":
    from config import RAW_DATA_PATH, LAG_FEATURES, ROLLING_WINDOWS, VALIDATION_WEEKS
    df = load_and_clean(RAW_DATA_PATH)
    print(f"Cleaned shape: {df.shape}")
    print(f"Date range: {df['Date'].min()} → {df['Date'].max()}")
    print(f"States: {df['State'].nunique()}")

    df = build_features(df, LAG_FEATURES, ROLLING_WINDOWS)
    print(f"After features: {df.shape}")
    print(f"Feature cols: {get_feature_columns(df)}")

    train, val = train_val_split(df, VALIDATION_WEEKS)
    print(f"Train: {train.shape}, Val: {val.shape}")
